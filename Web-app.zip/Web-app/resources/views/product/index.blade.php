@extends('layout.app')
@section('main')
       <div class="container">
        <div class="text-right">
          <a href="product/create" class="btn btn-dark mt-2">New Product</a>
        </div>
       <table class="table table-hover mt-2">
        <thead>
          <tr>
            <th>Sr.No</th>
            <th>Name</th>
            <th>Image</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
          @foreach($product as $product)
          <tr>
            <td>{{ $loop->index+1 }}</td>
            <td><a href="product/{{$product->id}}/show" class="text-dark">{{ $product->name }}</a></td>
            <td>
              <img src="product/{{ $product->image }}" class="rounded-circle" alt=""
              width="40" height="40">
            </td>
            <td>
              <a href="product/{{ $product->id }}/edit" class="btn btn-dark btn-sm">Edit</a>
              <a href="product/{{ $product->id }}/delete" class="btn btn-danger btn-sm">Delete</a>
            </td>
          </tr>
          @endforeach
        </tbody>
       </table>

    </div>
@endsection