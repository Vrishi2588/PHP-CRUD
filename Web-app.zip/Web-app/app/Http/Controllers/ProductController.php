<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\product;
use Symfony\Contracts\Service\Attribute\Required;

class ProductController extends Controller
{
    public function index(){
        return view('product.index',['product'=>product::get()]);    // fach product
    }
    public function create(){
        return view('product.create');
    }
    public function store(Request $request){
        //dd($request->all());
        // validation
        $request->validate([
            'name'=>'required',
            'description'=>'required',
            'image'=>'required|mimes:jpeg,jpg,png,gif|max:10000'
        ]);
        
        $imageName= time().'.'.$request->image->extension();
        $request->image->move(public_path('product'),$imageName);
       // dd($imageName);

       $product =new Product;
       $product->image = $imageName;
       $product->name = $request->name;
       $product->description = $request->description;
       $product->save();
       return back()->withSuccess('Product Created!!!');
    }

    public function edit($id){
        $product = Product::where('id',$id)->first();
        return view('product.edit',['product'=>$product]);
    }
    public function update(Request $request,$id){
        //dd($request->all());
        //dd($id);
        $request->validate([
            'name'=>'required',
            'description'=>'required',
            'image'=>'nullable|mimes:jpeg,jpg,png,gif|max:10000'
        ]);
        $product = Product::where('id',$id)->first();
        if(isset($request->image)){
            //upload images
            $imageName= time().'.'.$request->image->extension();
            $request->image->move(public_path('product'),$imageName);
        }      
       // dd($imageName);
       $product->name = $request->name;
       $product->description = $request->description;
       $product->save();
       return back()->withSuccess('Product Update!!!');
    }
    public function destroy($id){
        $product = Product::where('id',$id)->first();
        $product->delete();
        return back()->withSuccess('Product Delete !!!');
    }
    public function show($id){
        $product = Product::where('id',$id)->first();
        return view('product.show',['product'=>$product]);    
    }
}
