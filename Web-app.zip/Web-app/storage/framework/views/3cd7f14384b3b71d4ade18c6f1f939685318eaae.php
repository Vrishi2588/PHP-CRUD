
<?php $__env->startSection('main'); ?>
       <div class="container">
        <div class="text-right">
          <a href="product/create" class="btn btn-dark mt-2">New Product</a>
        </div>
       <table class="table table-hover mt-2">
        <thead>
          <tr>
            <th>Sr.No</th>
            <th>Name</th>
            <th>Image</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
          <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <td><?php echo e($loop->index+1); ?></td>
            <td><a href="product/<?php echo e($product->id); ?>/show" class="text-dark"><?php echo e($product->name); ?></a></td>
            <td>
              <img src="product/<?php echo e($product->image); ?>" class="rounded-circle" alt=""
              width="40" height="40">
            </td>
            <td>
              <a href="product/<?php echo e($product->id); ?>/edit" class="btn btn-dark btn-sm">Edit</a>
              <a href="product/<?php echo e($product->id); ?>/delete" class="btn btn-danger btn-sm">Delete</a>
            </td>
          </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
       </table>

    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Web-app\resources\views/product/index.blade.php ENDPATH**/ ?>